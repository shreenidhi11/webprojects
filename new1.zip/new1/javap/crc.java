
import java.util.Scanner;


public class crc {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the dataword");
        int data[]=new int[7];
        for(int i=0;i<4;i++)
        {
            data[i]=sc.nextInt();
        }
        int copy[]=new int[4];
        for(int i=0;i<4;i++)
        {
            copy[i]=data[i];
        }
        System.out.println("enter the divisor");
        int divi[]=new int[4];
        for(int i=0;i<4;i++)
            divi[i]=sc.nextInt();
        int app=4-1;
        for(int j=4;j<7;j++)
            data[j]=0;
        System.out.println("the appended code is");
        for(int i=0;i<7;i++)
        {
            System.out.println(data[i]);
        }
        
        System.out.println(".........................");
        int re[]=new int[5];
        int gen[]=new int[5];
      for(int k=0;k<3;k++) 
      {   
        if(data[0]==1)
        {
            for(int i=0;i<4;i++)
            {
                re[i]=divi[i] ^ data[i];
            }
            re[4]=0;
       /* for( int i=0;i<5;i++)
            System.out.println(re[i]);*/
        for(int i=1,j=0;i<=4;i++,j++)
        {
           data[j]=re[i];
            
        }
        
    System.out.println("the next data word is");
    for(int i=0;i<4;i++)
    {
        System.out.println(data[i]);
        
    }System.out.println(".......");
        }
        else
        {
            for(int i=0;i<4;i++)
            {
                re[i]=data[i]^0;
            }
            re[4]=0;
           /*for( int i=0;i<5;i++)
           System.out.println(re[i]);*/ 
           for(int i=1,j=0;i<=4;i++,j++)
        {
           data[j]=re[i];
            
        }
            System.out.println("the next data word is");
            
    for(int i=0;i<4;i++)
        {
        System.out.println(data[i]);
        }System.out.println(".........");
      } 
        
       
}
      System.out.println("the crc is");
      int crc[]=new int[7];
    for(int i=0;i<4;i++)
    {
        crc[i]=copy[i];
    }
    for(int i=4,j=1;i<7;i++,j++)
    {
        crc[i]=data[j];
    }
    for(int i=0;i<7;i++)
    System.out.println(crc[i]);
    
    
    
    System.out.println("reciever side");
    for(int k=4;k<7;k++)
        if(crc[0]==1)
        {
            for(int i=0;i<4;i++)
            {
                re[i]=crc[i]^divi[i];
            }
            re[4]=crc[k];
       /* System.out.println("the ans is");
        for(int i=0;i<5;i++)
            System.out.println(re[i]);*/
      for(int i=1,j=0;i<=4;i++,j++)
            {
           crc[j]=re[i];
            
            }
            System.out.println("the next data word is");
            for(int i=0;i<4;i++)
             {
                System.out.println(crc[i]);
             }
            System.out.println(".........");
        } 
        else
        {
          for(int i=0;i<4;i++)
            {
                re[i]=crc[i]^0;
            }  
          re[4]=crc[k];
          for(int i=1,j=0;i<=4;i++,j++)
            {
           crc[j]=re[i];
            
            }
            System.out.println("the next data word is");
            for(int i=0;i<4;i++)
             {
                System.out.println(crc[i]);
             }
            System.out.println(".........");
            
        }
   
    }
}
    

