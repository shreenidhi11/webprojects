

package sssp;

import java.util.Scanner;


public class Sssp {

   
    public static void main(String[] args) {
      Scanner sc=new Scanner(System.in);
     int graph[][]=new int[10][10];
     System.out.println("enter the number of nodes");
     int n=sc.nextInt();
     System.out.println("enter the graph");
     for(int i=0;i<n;i++)
     {
         for(int j=0;j<n;j++)
         {
          graph[i][j]=sc.nextInt();   
         }
        
    }
     dis d=new dis();
     d.status(n);
     d.dis1(n, graph);
     d.fs(n);
     d.change(n, graph);
    } 
}

class dis
{
    boolean s[]=new boolean[10];
    int v[]=new int[10];
    int i,u,min=99;
   void status(int n)
   {
     for(i=0;i<n;i++)
         s[i]=false;
    
   }
   void dis1(int n, int graph[][])
   {
       int k=0;
       for(i=0;i<n;i++)
       {
           v[i]=graph[k][i];
           System.out.println(v[i]);
       }
       
      s[k]=true; 
       
   }
   void fs(int n)
   {
      
     for(i=0;i<n;i++)
      System.out.println(s[i]);
    
    
   }
 
void mini(int n)
  {
      min=99;
   for(i=1;i<n;i++)
    {
     if(min>=v[i] && s[i]==false)
    {
     min=v[i];
     u=i;
    }
     else if(s[i]==false)
     {
      
       if(min>=v[i])
       {
           min=v[i];
           u=i;      
        }
      } 
    }
   s[u]=true;
   System.out.print("the index is" +u+ "the value is" +min);
  }
void change(int n,int graph[][])
{
    for(int m=0;m<n;m++)
    {
     mini(n);   
    for( int j=0;j<n;j++)
    {
        
        if(s[j]==false && v[j]>graph[u][j]+v[u])
        {
            s[j]=true;
           v[j]=v[u]+graph[u][j];
           System.out.println(v[j]);
        }
        
    }
   }
    System.out.println();
    System.out.println("the final path is");
    for(i=0;i<n;i++)
        System.out.println(v[i]);
}
}
